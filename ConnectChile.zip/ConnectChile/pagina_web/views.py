from django.shortcuts import render, redirect,  get_object_or_404
from .models import Factibilidad, Soporte, Servicio, Plan, Usuario, Anuncio
from django.http import HttpResponseRedirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt


def inicio(request):
    anuncios = Anuncio.objects.all().order_by('creado')
    return render(request, 'inicio.html', {'anuncios': anuncios})


def login(request):
    if request.method == 'POST':
        correo = request.POST.get('correo')
        contraseña = request.POST.get('contraseña')

        try:
            usuario = Usuario.objects.get(correo=correo, contraseña=contraseña)


            request.session['usuario_id'] = usuario.id
            request.session['usuario_nombre'] = usuario.nombre
            request.session['usuario_correo'] = usuario.correo

            return redirect('/') 

        except Usuario.DoesNotExist:
            return render(request, 'iniciar_sesion.html', {
                'error': 'Correo o contraseña inválidos'
            })

    return render(request, 'iniciar_sesion.html')

def logout_view(request):
    request.session.flush()
    return redirect('/')

def registro_factibilidad(request):
    if request.method == 'POST':
        nueva_factibilidad = Factibilidad (
            nombre = request.POST.get('nombre'),
            correo = request.POST.get('correo'),
            telefono = request.POST.get('telefono'),
            direccion = request.POST.get('direccion'),
            localidad = request.POST.get('localidad'),
            plan = request.POST.get('plan')
        )
        nueva_factibilidad.save()
        messages.success(request, "Solicitud de factibilidad enviada correctamente, espere a ser llamado")

        return HttpResponseRedirect('/')
    return render(request, 'factibilidad.html')

def planes(request):
    planes = Plan.objects.all()
    return render(request, 'planes.html', {'planes': planes})

def servicios(request):
    servicios = Servicio.objects.all()
    return render(request, 'servicios.html', {'servicios': servicios})


def soporte(request):
    if request.method == 'POST':
        nuevo_ticket = Soporte (
            nombre = request.POST.get('nombre'),
            correo = request.POST.get('correo'),
            telefono = request.POST.get('telefono'),
            mensaje = request.POST.get('mensaje'),
        )
        nuevo_ticket.save()
        messages.success(request, "Solicitud de soporte enviado correctamente, lo llamaremos a la brevedad.")

        return HttpResponseRedirect('/')
    return render(request, 'soporte.html')

def agregar_plan(request):
    if request.method == 'POST':
        nuevo_plan = Plan (
            nombre = request.POST.get('nombre'),
            descripcion = request.POST.get('descripcion'),
            precio = request.POST.get('precio'),
        )
        nuevo_plan.save()
        messages.success(request, "Plan agregado con éxito a la base de datos.")
        return HttpResponseRedirect('/')
    return render(request, 'agregar_plan.html')

def editar_plan(request, plan_id):
    if not request.session.get('usuario_id'):
        return redirect('/login/')  

    plan = get_object_or_404(Plan, id=plan_id)

    if request.method == 'POST':
        plan.nombre = request.POST.get('nombre')
        plan.precio = request.POST.get('precio')
        plan.descripcion = request.POST.get('descripcion')
        plan.save()
        return redirect('/planes/')

    return render(request, 'editar_plan.html', {'plan': plan})


def eliminar_plan(request, plan_id):
    if not request.session.get('usuario_id'):
        return redirect('/login/')

    plan = get_object_or_404(Plan, id=plan_id)
    
    if request.method == 'POST':
        plan.delete()
        return redirect('/planes/')

    return render(request, 'confirmar_eliminacion.html', {'plan': plan})

@csrf_exempt
def guardar_anuncio(request):
    if request.method == 'POST':
        texto = request.POST.get('texto')
        if texto:
            Anuncio.objects.all().delete()  
            Anuncio.objects.create(texto=texto)
    return redirect('/')


