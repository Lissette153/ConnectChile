
from django.db import models

class Factibilidad(models.Model):
    LOCALIDADES = [
       ('panguipulli', 'Panguipulli'),
        ('etchegaray', 'Serie Etchegaray'),
        ('roble_huacho', 'Sector Roble Huacho'),
        ('coz', 'Coz coz'),
        ('melefquen', 'Melefquen'),
        ('malalhue', 'Malalhue'),
        ('licanray', 'Licanray'),
        ('conaripe', 'Coñaripe'),
        ('pilingue', 'Pilingue'),
        ('calafquen', 'Calafquen'),
        ('anhuaraqui', 'Anhuaraqui'),
        ('huerquehue', 'Huerquehue'),
        ('tallos', 'Los Tallos'),
        ('monje', 'Playa Monje'),
        ('playa_coz', 'Playa Coz coz'),
        ('chauquen', 'Chauquen'),
        ('pullinque', 'Villa Pullinque'),
        ('bocatoma', 'Bocatoma'),
        ('pelehue', 'Pelehue'),
        ('pelipulli', 'Pelipulli'),
    ]
    
    PLANES = [
        ('plan_15', 'Plan 15MB'),
        ('plan_25', 'Plan 25MB'),
        ('plan_35', 'Plan 35MB'),
    ]



    nombre = models.CharField(max_length=100)
    correo = models.CharField(max_length=100)
    telefono = models.CharField(max_length=20)
    direccion = models.CharField(max_length=200)
    localidad = models.CharField(max_length=50, choices=LOCALIDADES)
    plan = models.CharField(max_length=30, choices=PLANES)

    class Meta:
        managed = False
        db_table = 'factibilidad'


class Plan(models.Model):
    nombre = models.CharField(max_length=100)
    descripcion = models.CharField(max_length=30)
    precio = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'plan'


class Servicio(models.Model):
    nombre = models.CharField(max_length=20)
    descripcion = models.CharField(max_length=250, blank=True)
    imagen = models.CharField(max_length=300)

    class Meta:
        managed = False
        db_table = 'servicio'



class Usuario(models.Model):
    nombre = models.CharField(max_length=50)
    correo = models.CharField(max_length=100)
    contraseña = models.CharField(max_length=10)

    class Meta:
        managed = False
        db_table = 'usuario'
        

class Soporte(models.Model):
    nombre = models.CharField(max_length=50)
    apellido = models.CharField(max_length=50)
    correo = models.CharField(max_length=100)
    telefono = models.CharField(max_length=20)
    mensaje = models.CharField(max_length=500)

    class Meta:
        managed = False
        db_table = 'soporte'


class Anuncio(models.Model):
    texto = models.CharField(max_length=100)
    creado = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.texto[:50]

    class Meta:
        db_table = "pagina_web_anuncio"
