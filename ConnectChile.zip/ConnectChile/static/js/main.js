document.addEventListener('DOMContentLoaded', function() {
  const swiper = new Swiper('.elementor-main-swiper', {
    // —— Element settings from data-settings ——  
    loop: true,                      // infinite: yes  
    speed: 500,                      // transition_speed: 500 (ms)  
    effect: 'slide',                 // transition: slide  
    autoplay: {
      delay: 5000,                   // autoplay_speed: 5000 (ms)  
      disableOnInteraction: false,   // pause_on_interaction: yes  
      pauseOnMouseEnter: true        // pause_on_hover: yes  
    },

    // —— Pagination (bullets) ——  
    pagination: {
      el: '.swiper-pagination',
      clickable: true
    },

    // —— Navigation arrows ——  
    navigation: {
      nextEl: '.elementor-swiper-button-next',
      prevEl: '.elementor-swiper-button-prev'
    }
  });
});
