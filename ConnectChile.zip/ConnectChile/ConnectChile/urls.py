
from django.contrib import admin
from django.urls import path
from pagina_web import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.inicio, name="inicio"),
    path('planes/', views.planes),
    path('editar-plan/<int:plan_id>/', views.editar_plan, name='editar_plan'),
    path('planes/agregar_plan/', views.agregar_plan, name='agregar_plan'),
    path('servicios/', views.servicios),
    path('soporte/', views.soporte, name="soporte"),
    path('factibilidad/', views.registro_factibilidad, name='factibilidad'),
    path('login/', views.login, name="login"),
    path('logout/', views.logout_view, name='logout'),
    path('eliminar-plan/<int:plan_id>/', views.eliminar_plan, name='eliminar_plan'),
    path('guardar-anuncio/', views.guardar_anuncio, name='guardar_anuncio'),
]
